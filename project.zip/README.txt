DRAWING MARKER STUDIO v20 - ANDROID APK BUILD PACKAGE
=====================================================
Fully offline: the app, pdf.js and pdf-lib are all inside the APK (no internet needed).
Package id: org.suroj.drawingmarker   |   Android 8.0 (API 26) and above

OPTION A - Build online with GitHub (no installs, ~5 minutes)
 1. Create a free account at github.com and make a new PRIVATE repository.
 2. Upload everything from this folder (drag & drop; keep the .github folder).
 3. Open the repository > Actions tab > "Build APK" > Run workflow.
 4. When it turns green, open the run > Artifacts > download "Drawing-Marker-Studio-APK" (zip).
 5. Unzip, copy app-debug.apk to the phone, tap it, allow "Install unknown apps".

OPTION B - Android Studio on a PC
 1. Install Android Studio, choose File > Open and pick this folder.
 2. Wait for Gradle sync, then Build > Build APK(s).
 3. APK: app/build/outputs/apk/debug/app-debug.apk

Using the app
 - "Open PDF" uses the Android file picker.
 - Download / Export buttons open Android's "Save as" screen so you choose the folder.
 - Back button: press twice within 2 seconds to exit.

Updating later: replace app/src/main/assets/index.html with the new version
(keep the three ./lib/ import paths), raise versionCode in app/build.gradle, rebuild.

Note: this is a debug-signed APK, fine for your own staff phones. A Play Store release
needs a release keystore.
