package org.suroj.drawingmarker;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Drawing Marker Studio - offline WebView wrapper.
 * The whole app (index.html + pdf.js + pdf-lib) is inside the APK's assets and is served
 * from a fake https origin so ES modules, workers, IndexedDB and localStorage all work offline.
 */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_OPEN = 101, REQ_SAVE = 102;

    private WebView web;
    private ValueCallback<Uri[]> chooserCallback;

    // pending download
    private ByteArrayOutputStream dlBuf;
    private String dlName = "drawing.pdf", dlMime = "application/octet-stream";
    private byte[] dlReady;

    private long lastBack = 0;

    // Makes <a download href="blob:..."> clicks save through Android's "Save as" screen.
    private static final String HOOK =
        "(function(){if(window.__dmsHook)return;window.__dmsHook=1;" +
        "var orig=HTMLAnchorElement.prototype.click;" +
        "HTMLAnchorElement.prototype.click=function(){var a=this;" +
        "if(a.hasAttribute('download')&&/^(blob:|data:)/.test(a.href)){" +
        "fetch(a.href).then(function(r){return r.blob()}).then(function(b){" +
        "var fr=new FileReader();fr.onload=function(){var s=String(fr.result),d=s.substring(s.indexOf(',')+1);" +
        "AndroidBridge.begin(a.download||'file',b.type||'application/octet-stream');" +
        "for(var i=0;i<d.length;i+=262144){AndroidBridge.chunk(d.substring(i,i+262144));}" +
        "AndroidBridge.end();};fr.readAsDataURL(b);});return;}" +
        "return orig.apply(this,arguments);};})();";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                try {
                    InputStream in = getAssets().open(path.substring(1));
                    WebResourceResponse r = new WebResourceResponse(mime(path), "UTF-8", in);
                    return r;
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found", null, null);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                // keep everything inside the app
                return !HOST.equals(req.getUrl().getHost()) && !"blob".equals(req.getUrl().getScheme());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(HOOK, null);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_OPEN);
                } catch (Exception e) {
                    chooserCallback = null;
                    Toast.makeText(MainActivity.this, "Cannot open file picker", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("https://" + HOST + "/index.html");
    }

    private static String mime(String p) {
        p = p.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "text/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".wasm")) return "application/wasm";
        return "application/octet-stream";
    }

    /** Called from JavaScript (background thread). */
    private class Bridge {
        @JavascriptInterface
        public void begin(String name, String mime) {
            dlBuf = new ByteArrayOutputStream();
            dlName = (name == null || name.isEmpty()) ? "file" : name;
            dlMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
        }

        @JavascriptInterface
        public void chunk(String base64) {
            try {
                if (dlBuf != null) dlBuf.write(android.util.Base64.decode(base64, android.util.Base64.DEFAULT));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void end() {
            if (dlBuf == null) return;
            dlReady = dlBuf.toByteArray();
            dlBuf = null;
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(dlMime);
                    i.putExtra(Intent.EXTRA_TITLE, dlName);
                    try {
                        startActivityForResult(i, REQ_SAVE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Cannot open Save screen", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OPEN) {
            if (chooserCallback == null) return;
            Uri[] r = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    r = new Uri[n];
                    for (int i = 0; i < n; i++) r[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    r = new Uri[]{data.getData()};
                }
            }
            chooserCallback.onReceiveValue(r);
            chooserCallback = null;
        } else if (req == REQ_SAVE) {
            if (res == RESULT_OK && data != null && data.getData() != null && dlReady != null) {
                try {
                    OutputStream out = getContentResolver().openOutputStream(data.getData(), "wt");
                    out.write(dlReady);
                    out.close();
                    Toast.makeText(this, "Saved: " + dlName, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            dlReady = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) {
            super.onBackPressed();
        } else {
            lastBack = now;
            Toast.makeText(this, "Press back again to exit (unsaved markings will be lost)", Toast.LENGTH_SHORT).show();
        }
    }
}
